def handler(event, context=None):
    print('Start GET etl Lambda Function')
    print(event)
    return event

